# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 13:11:04 2017

@author: Daniel Wehner
"""
import nltk
from nltk.corpus import udhr

# Task 4.1
# ******************************************************************************************
# ******************************************************************************************

# build language models using nltk.ConditionalFreqDist
#
# @param languages : list (list of languages)
# @param words : dictionary (dictionary)
# @return nltk.ConditionalFreqDist
def build_language_models(languages, words):
    return nltk.ConditionalFreqDist( # (condition, data)
        (language, character.lower())
            for language in languages
            for word in words[language]
            for character in word if character.isalpha())

# calculate the FreqDist for the characters of the text given
#
# @param text : string
# @param language_model_cfd : nltk.ConditionalFreqDist
# @return nltk.FreqDist
#
# Explanation:
# ============
# The algorithm first computes the relative frequencies of the
# characters in the text. It then compares these values with
# the realtive frequencies of the characters in each language, computes the differences and
# eliminates the signs. The resulting values are summed up for each language. That means the greater the sum
# for the language the less probable it is that the text is written in that language.
# A sum of zero for a language indicates that the character distributions of the text and the model
# are equal (It is therefore very likely that the text was written in that language).
# 
# E.g. the relative frequency of letter 'u' in the text to be rated is
# 0.025 and for the German language it is 0.046. The algorithm then computes the difference
# and eliminates the signs -> |0.025 - 0.046| = 0.021. This is done for every letter and every language.
# The resulting sums per language indicate how distant the text and the models are.
def rate_text(text, language_model_cfd):
    words = nltk.word_tokenize(text)
    fd_text = nltk.FreqDist(
        character.lower()
            for word in words
            for character in word if character.isalpha())
    
    #for key in list(fd_text.keys()):
    #    print(key, "->", fd_text.freq(key))
    
    # create empty dictionary
    distances = {}
    for language in language_model_cfd:
        distance = 0
        for key in list(fd_text.keys()):
            distance += abs(fd_text.freq(key) - language_model_cfd[language].freq(key))
        distances[language] = distance
    return distances

# guess the language of the text given using the
# language model created earlier
#
# @param language_model_cfd : nltk.ConditionalFreqDist
# @param text : string
def guess_language(language_model_cfd, text):
    result = rate_text(text, language_model_cfd)
    return min(result, key = result.get)

# list of languages
languages = ["English", "German_Deutsch", "French_Francais"]
# dictionary
# udhr contains the Universal Declaration of Human Rights in over 300 languages
language_base = dict(
    (language, udhr.words(language + "-Latin1"))
    for language in languages)
# build language model
language_model_cfd = build_language_models(languages, language_base)

# print the models for visual inspection
for language in languages:
    for key in list(language_model_cfd[language].keys()):
        print(language, key, "->", language_model_cfd[language].freq(key))

# Test the implementation     
# =========================================================================================
text1 = "Peter had been to the office before they arrived."
text2 = "Si tu finis tes devoirs, je te donnerai des bonbons."
text3 = "Das ist ein schon recht langes deutsches Beispiel."

print()
print("Results for language guess by char frequencies:")
print("===============================================")
print("Guess for English text is", guess_language(language_model_cfd, text1))
print("Guess for French text is", guess_language(language_model_cfd, text2))
print("Guess for German text is", guess_language(language_model_cfd, text3))
print()

# e) German and English texts are hard to distinguish in this case beacuse these two languages have
# a similar character distribution and therefore the distances are close to each other.
# This can be a problem especially for short texts.

# Task 4.2
# ******************************************************************************************
# ******************************************************************************************

# create language model for tokens
language_model_token = nltk.ConditionalFreqDist(
    (language, word)
        for language in languages
        for word in language_base[language])

# create language model for char bigrams
language_model_char_bigram = nltk.ConditionalFreqDist(
    (language, char_bigram)
        for language in languages
        for word in language_base[language]
        for char_bigram in nltk.bigrams(word))

# create language model for token bigrams
language_model_token_bigram = nltk.ConditionalFreqDist(
    (language, token_bigram)
        for language in languages
        for token_bigram in nltk.bigrams(language_base[language]))

# generic version of rate text
#
# @param language_model : nltk.ConditionalFreqDist
# @param text_fd : nltk.FreqDist
# @return distances : dictionary (dictionary of distances for each language)
def rate_text_generic(language_model, text_fd):
    # create empty dictionary
    distances = {}
    for language in language_model:
        distance = 0
        for key in list(text_fd.keys()):
            distance += abs(text_fd.freq(key) - language_model[language].freq(key))
        distances[language] = distance
    return distances

# generic version of guess_language
#
# @param language_model : nltk.ConditionalFreqDist
# @param text_fd : nltk.FreqDist
# @return language guess (key with minimum value in dictionary)
def guess_language_generic(language_model, text_fd):
    result = rate_text_generic(language_model, text_fd)
    return min(result, key = result.get)

# gets the language for a text specified
#
# @param language_model : nltk.ConditionalFreqDist
# @param text : String (text to be classified)
# @param guessType : String ("token", "char_bigrams", "token_bigrams")
def get_language(language_model, text, guessType):
    text_fd = None
    
    #for language in language_model:
    #    for key in list(language_model[language].keys()):
    #        print(language, key, "->", language_model[language].freq(key))
    
    # create language model by tokens
    if guessType == "token":
        text_fd = nltk.FreqDist(word for word in nltk.word_tokenize(text))
    elif guessType == "char_bigrams":
        text_fd = nltk.FreqDist(bgr for word in nltk.word_tokenize(text) for bgr in nltk.bigrams(word))
    else:
        text_fd = nltk.FreqDist(bgr for bgr in nltk.bigrams(nltk.word_tokenize(text)))
    
    return guess_language_generic(language_model, text_fd)

# print results
# =========================================================================================================
    
# a)
print("Results for language guess by tokens:")
print("=====================================")
print("Guess for English text is: ", get_language(language_model_token, text1, "token"))
print("Guess for French text is: ", get_language(language_model_token, text2, "token"))
print("Guess for German text is: ", get_language(language_model_token, text3, "token"))
print()

# b)
print("Results for language guess by char bigrams:")
print("===========================================")
print("Guess for English text is: ", get_language(language_model_char_bigram, text1, "char_bigrams"))
print("Guess for French text is: ", get_language(language_model_char_bigram, text2, "char_bigrams"))
print("Guess for German text is: ", get_language(language_model_char_bigram, text3, "char_bigrams"))
print()

# c)
print("Results for language guess by token bigrams:")
print("============================================")
print("Guess for English text is: ", get_language(language_model_token_bigram, text1, "token_bigrams"))
print("Guess for French text is: ", get_language(language_model_token_bigram, text2, "token_bigrams"))
print("Guess for German text is: ", get_language(language_model_token_bigram, text3, "token_bigrams"))
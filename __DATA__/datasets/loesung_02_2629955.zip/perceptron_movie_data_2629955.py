# -*- coding: utf-8 -*-
"""
Created on Thu Apr 19 06:49:00 2018

@author: Daniel Wehner
DL4NLP (Homework 2)
"""

import os
import math
import numpy as np

np.random.seed(42)


def read_data(file_name):
    """
    Reads the data file and returns X (data) and y (labels)
    as numpy arrays.
    
    :file_name:     name of the file to be read
    :return:        data (X) and labels (y) as numpy arrays
    """
    # init X and y
    X = []
    y = []
    
    file_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "DATA", file_name)
    )
        
    with open(file_path, "r") as f:
        for line in f:
                
            # remove spaces, newlines, ...
            line = line.strip()
                
            # split into tokens
            # tokens[0] => review text
            # tokens[1] => label
            # tokens[2] => word vector
            tokens = line.split("\t")
            row = np.fromstring(tokens[2], dtype=float, sep=" ")
            X.append(row)
                
            # prepare labels
            y.append([1] if tokens[1].split("=")[1] == "POS" else [0])
        
    X = np.asarray(X)
    y = np.asarray(y)
    return X, y


def perceptron(X, y, alpha=0.01, batch_size=10, epochs=100):
    """
    Train a perceptron.
    
    :X:             training data
    :y:             training labels
    :alpha:         learning rate
    :batch_size:    batch size
    :epochs:        number of epochs
    :return:        learned weights
    """
    # reduce batch size if it is greater than size of dataset
    if batch_size > X.shape[0]:
        batch_size = X.shape[0]
    w = np.random.normal(0, 1, (X.shape[1], 1))
    
    # perform epochs
    for _ in range(epochs):
        X, y = unison_shuffled_copies(X, y)
        
        b = 0           # begin batch
        e = batch_size  # end batch
        while e <= X.shape[0]:
            
            mini_X = X[b:e]
            mini_y = y[b:e]
            b = e
            e += batch_size
        
            # calculate preactivation and activation
            preact = np.dot(mini_X, w)
            act = sigVect(preact)
     
            # update weights
            w -= (alpha / batch_size) * np.dot(
                np.transpose(mini_X), ((act - mini_y) * sigPrimeVect(preact))
            )
        print(square_loss(X, y, w))
    return w


def unison_shuffled_copies(a, b):
    """
    Shuffles two arrays a and b together.
    
    :a:             array a
    :b:             array b
    :return:        (shuffled a, shuffled b)
    """
    assert len(a) == len(b)
    p = np.random.permutation(len(a))
    return a[p], b[p]


def sig(x):
    """
    Sigmoid activation function.
    
    :x:         preactivation
    :return:    activation
    """
    # prevent math range error when x is too small/big
    if x < -300: return 0
    if x > 300: return 1
    return 1 / (1 + math.exp(-x))


def sigPrime(x):
    """
    1st derivative of sigmoid activation function.
    
    :x:         preactivation
    :return:    result
    """
    return sig(x) * (1 - sig(x))


def square_loss(X, y, w):
    """
    Calculates the square loss.
    
    :X:         data
    :y:         labels
    :w:         weights
    :return:    square loss
    """
    loss = 0.0
    for i, x in enumerate(X):
        loss += math.pow(sig(np.dot(x, w)) - y[i][0], 2)
    return loss


def calc_accuracy(X, y, w):
    """
    Calculates accuracy.
    
    :X:         data
    :y:         labels
    :w:         weights
    :return:    accuracy
    """
    act = sigVect(np.dot(X, w))
    # if activation greater 0.5     => class 1 (POS)
    # if activation less equal 0.5  => class 0 (NEG)
    pred = np.where(act > 0.5, 1, 0)
    return sum(pred == y) / X.shape[0]
    

# vectorize functions in order to be able to apply them to entire arrays at once
sigVect = np.vectorize(sig)
sigPrimeVect = np.vectorize(sigPrime)

# read training data
X_train, y_train = read_data("rt-polarity.train.vecs")

# or-problem for reference and testing perceptron
# (should reach 100 % accuracy on test set, since linearly separable)
#X_train = np.array([[0,0], [0,1], [1,0], [1,1]])
#y_train = np.array([[0], [1], [1], [1]])

# add 1 (bias) to training data
X_train = np.concatenate((X_train, np.ones((X_train.shape[0], 1))), axis=1)
w = perceptron(X_train, y_train, alpha=0.01, batch_size=1, epochs=500)

# evaluation of or-problem
#print("Accuracy", calc_accuracy(X_train, y_train, w))

# read development data
X_dev, y_dev = read_data("rt-polarity.dev.vecs")
# add 1 (bias) to development data
X_dev = np.concatenate((X_dev, np.ones((X_dev.shape[0], 1))), axis=1)

print("Accuracy dev", calc_accuracy(X_dev, y_dev, w))
print("Loss dev", square_loss(X_dev, y_dev, w))

#read test data
X_test, y_test = read_data("rt-polarity.test.vecs")
# add 1 (bias) to test data
X_test = np.concatenate((X_test, np.ones((X_test.shape[0], 1))), axis=1)

print("Accuracy test", calc_accuracy(X_test, y_test, w))
print("Loss test", square_loss(X_test, y_test, w))
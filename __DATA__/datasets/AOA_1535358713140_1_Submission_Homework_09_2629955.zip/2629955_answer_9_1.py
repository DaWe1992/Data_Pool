# -*- coding: utf-8 -*-
"""
Created on Tue Dec 19 12:35:05 2017

@author: D062271
"""

import nltk
import random
from nltk.corpus import sentiwordnet as swn, stopwords
from nltk.corpus import movie_reviews

# import data
review_data = [(movie_reviews.words(fileid), category)
                    for category in movie_reviews.categories()
                    for fileid in movie_reviews.fileids(category)]
stoppers = stopwords.words("english")

random.seed(1)
random.shuffle(review_data)

def split_data(data):
    """
    Splits the data into train set, development set and test set
    """
    nr_review = len(review_data)
    return (data[:((nr_review * 8) // 10)],
            data[((nr_review * 8) // 10):((nr_review * 9) // 10)],
            data[((nr_review * 9) // 10):])

# =============================================================================
def get_sentiment_score_for_word(word):
    """
    Calculates the sentiment score for a single word
    """
    list_senti_synsets = list(swn.senti_synsets(word))
    if len(list_senti_synsets) == 0: return 0
    
    score = 0
    for synset in list_senti_synsets:
        if synset.obj_score() < 0.25:
            if synset.pos_score() > 0.5: score += synset.pos_score()
            if synset.neg_score() > 0.5: score -= synset.neg_score()
        
    return score

def get_sentiment_score(words):
    """
    Calculates the sentiment score for a list of words
    """
    words = [w for w in words if w in top_words and w not in stoppers]
    score = 0.0
    
    for word in words:
        score += get_sentiment_score_for_word(word)
        
    return score

# =============================================================================
#top_words = None

def get_frequent_words(review):
    #global top_words
    
    
    #if(top_words == None):
    #fd_all_words = nltk.FreqDist(w.lower() for w in movie_reviews.words())
    #top_words = [w for (w, f) in fd_all_words.most_common(threshold)]
        
    return nltk.FreqDist(w.lower() for w in review
                             if w in top_words) # and w not in stoppers)
    
    # convert to relative frequencies
    #dct = nltk.defaultdict(float)
    #for k, v in fd.items():
    #    dct[k] = fd.freq(k)
    #    
    #return dct
    
def get_n_grams(review, n):
    return nltk.FreqDist(nltk.ngrams((w.lower() for w in review), n))

def get_features(instance):
    """
    Extracts the features from the instance
    """
    fd = get_frequent_words(instance)
    fd.update(get_n_grams(instance, 2))
    #fd = {
    #    "sentiment_score": get_sentiment_score(instance)        
    #}
    return fd
    
# split the data
train_data, devel_data, test_data = split_data(review_data)

train_data_words = [w for w, t in train_data]

flatten = lambda l: [item for sublist in l for item in sublist]

threshold = 2000
fd_all_words = nltk.FreqDist(w.lower() for w in flatten(train_data_words))
top_words = [w for (w, f) in fd_all_words.most_common(threshold)]

train_data = [(get_features(words), t) for words, t in train_data]
devel_data = [(get_features(words), t) for words, t in devel_data]
test_data = [(get_features(words), t) for words, t in test_data]

classifier = nltk.NaiveBayesClassifier.train(train_data)
print(nltk.classify.accuracy(classifier, test_data))
classifier.show_most_informative_features(10)

#print(get_sentiment_score(["I", "am", "so", "depressed", "."]))
#print(get_sentiment_score(["I", "feel", "very", "happy", "."]))
#print(get_features(review_data[1000][0]))

"""
Results:
========

Tuning on development data
Step 1:  0.720 (word frequencies, 2000 most common)
Step 2:  0.665 (word frequencies without stop words, 2000 most common)
Step 3:  0.765 (bigrams, without most common words -> no filtering)
Step 4:  0.760 (trigrams, without most common words -> no filtering)
Step 5:  0.775 (combination of steps 1 and 3)
Step 6:  0.545 (only senti-word-net without most common words)
Step 7:  0.530 (only senti-word-net with 2000 most common)
Step 8:  0.720 (like 5 but also most common words for bigrams -> probably context gets lost)
Step 9:  0.490 (like 1 but relative frequencies instead of absolute frequencies)
Step 10: 0.750 (like 5, but using 4000 most common words for word frequencies)
Step 11: 0.775 (like 5, but using 500 most common words for word frequencies)
Step 12: 0.775 (like 5, but using 100 most common words for word frequencies)
"""
